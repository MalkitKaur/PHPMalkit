<?php
// Start a session to manage user sessions
session_start();
// Check if the userId session variable is not set (user is not logged in)
if (!isset($_SESSION["userId"])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>My Assignment</title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <!-- Header section -->
<header>
    <nav>
      <div>
        <!-- Logo link that leads back to the login page -->
        <a href="login.php"><img src="./img/blcklogo.jpg" alt="header logo"></a>
        <div>
          <ul>
            <!-- Links for Sign Up and Log In-->
            <li><a href="#signup">Sign Up</a></li>
            <li><a href="#signin">Log In</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!-- Content section -->
    <div class="confirm">
        <h3>Welcome !! You are Logged In.</h3>
        <p>Have a good day !!</p>
        <!-- Logout button that leads to the logout.php page -->
        <a class="btn" href="logout.php">Logout </a>
    </div>

    <!-- Footer section -->
    <footer class="bottom">
        <p>&copy; 2023 Malkit Kaur. All Rights Reserved</p>
    </footer>
</body>
</html>