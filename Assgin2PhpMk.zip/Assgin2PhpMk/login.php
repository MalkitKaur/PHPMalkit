<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Php Assignment 2 Malkit</title>
  <meta name="description"
    content="This week we will look at how we can protect pages behind a level of authenication.">
  <meta name="robots" content="noindex, nofollow">
  <link rel="stylesheet" href="./css/style.css">
</head>

<body>
  <!-- Header section -->
  <header>
    <nav>
      <div>
        <!-- Logo link that leads back to the login page -->
        <a href="login.php"><img src="./img/blcklogo.jpg" alt="header logo"></a>
        <div>
          <ul>
            <!-- Links for Sign Up and Log In sections-->
            <li><a href="#signup">Sign Up</a></li>
            <li><a href="#signin">Log In</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!-- Main content section -->
  <main>
    <section>
      <!-- Sign Up section . Creating forms here-->
      <h2>SIGN UP</h2>
      <div class="forms" id="signup">
        <form method="post" action="save-admin.php" class="form">
          <p><label for="userName">Username:</label></p>
          <p><input name="userName" type="text" placeholder="Username" required /></p>
          <p><label for="firstName">First Name:</label></p>
          <p><input name="firstName" type="text" placeholder="First Name" required /></p>
          <p><label for="lastName">Last Name:</label></p>
          <p><input name="lastName" type="text" placeholder="Last Name" required /></p>
          <p><label for="mail">Email Address:</label></p>
          <p><input name="mail" type="email" placeholder="Write your Email" required /></p>
          <p><label for="pass">Password:</label></p>
          <p><input name="pass" type="password" placeholder="Password" required /></p>
          <p><label for="confirmPass">Re-enter your password:</label></p>
          <p><input name="confirmPass" type="password" placeholder="Enter your Password again" required /></p>
          <input type="submit" name="submit" value="CREATE ACCOUNT" />
        </form>
      </div>
      <h2>SIGN IN</h2>
      <div id="signin" class="form">
        <form method="post" action="validate.php">
          <p><label for="userName">Username:</label></p>
          <input type="text" name="userName" required>
          <p>
          <p><label for="pass">Password:</label></p>
          <input type="password" name="pass" required>
          </p>
          <input type="submit" value="LOG IN">
        </form>
      </div>
    </section>
  </main>
  <!-- Footer section -->
  <footer class="bottom">
    <p>&copy; 2023 Malkit Kaur. All Rights Reserved</p>
  </footer>
</body>

</html>