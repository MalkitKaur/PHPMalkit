<?php
// Get user input from the POST request
$userName = $_POST['userName'];
$pass = hash('sha512', $_POST['pass']);
// Include the database connection configuration
require 'database.php';
// Prepare SQL query to select userId based on username and hashed password
$sql = "SELECT userId FROM newUser WHERE userName= '$userName' AND pass= '$pass'";
// Execute the SQL query and get the result
$result = $connection->query($sql);
// Get the number of rows returned by the query
$frequency = $result->rowCount();
// Check if a single matching record was found
if ($frequency == 1) {
    echo '<p>Logged in successfully</p>';
    foreach ($result as $row) {
        session_start();
        $_SESSION['userId'] = $row['userId'];
        Header('Location: loginsuccess.php');
    }
} else {
    echo '<p>Login Failed</p>';
}
$connection = null;
?>