<?php
// Include the database connection configuration
require 'database.php';
// Get user input from the POST request
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$userName = $_POST['userName'];
$pass = $_POST['pass'];
$confirmPass = $_POST['confirmPass'];

$correct = true;
// Check if the First Name field is empty
if (empty($firstName)) {
  echo '<p> Enter your First Name!! </p>';
  $correct = false;
}
// Check if the Last Name field is empty
if (empty($lastName)) {
  echo '<p> Enter your Last Name!! </p>';
  $correct = false;
}
// Check if the Username field is empty
if (empty($userName)) {
  echo '<p> Enter your Password!!</p>';
  $correct = false;
}
// Check if the Password field is empty or if passwords don't match
if ((empty($pass)) || ($pass != $confirmPass)) {
  echo '<p>Passwords do not match!!</p>';
  $correct = false;
}
// If all input data is correct, proceed
if ($correct) {
  $pass = hash('sha512', $pass);
  $sql = "INSERT INTO newUser (firstName, lastName, userName, pass) VALUES 
	('$firstName', '$lastName', '$userName', '$pass');";
  $connection->exec($sql);
  echo '<section">';
  echo '<div>';
  echo '<h1> ACCOUNT CREATED! </h1>';
  echo '</div>';
  echo '</section>';
  $connection = null;
}
?>

<head>
  <title>My Assignment</title>
  <link rel="stylesheet" href="./css/style.css">
</head>
<section class="saved">
  <div>
    <p>Passwords do not match!!</p>
    <p>Log In Here !!</p>
    <a href="login.php" class="btn">Sign In</a>
  </div>
</section>
<footer class="bottom">
  <p>&copy; 2023 Malkit Kaur. All Rights Reserved</p>
</footer>