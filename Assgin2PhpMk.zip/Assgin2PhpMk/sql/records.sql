CREATE table newUser(
    userId int not null auto_increment,
    userName varchar(255),
    firstName varchar(255),
    lastName varchar(255),
    mail varchar(255),
    pass varchar(255),
    primary key (userId)
);
