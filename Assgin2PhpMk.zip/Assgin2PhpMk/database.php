<?php
	try {
        // Establishing a connection to the MySQL database
		$connection = new PDO('mysql:host=172.31.22.43;dbname=Malkit200543614', 'Malkit200543614', 'StBWEnstVE');
        // Set the error mode to exception for better error handling
		$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $exptn) {
        // If connection fails, display an error message with the exception details
		die("Connection not established!! " . $exptn->getMessage());
	}
?>
