<?php
// Start a session to manage user sessions
session_start();
// Destroy the current session, logging the user out
session_destroy();
// Redirect the user to the login page after logging out
header("Location: login.php");
?>